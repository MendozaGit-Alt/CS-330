#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>
#include <cstdint>

class SceneManager
{
public:
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    struct TEXTURE_INFO
    {
        std::string tag;
        uint32_t ID;
    };

    struct OBJECT_MATERIAL
    {
        float ambientStrength;
        glm::vec3 ambientColor;
        glm::vec3 diffuseColor;
        glm::vec3 specularColor;
        float shininess;
        std::string tag;
    };

private:
    ShaderManager* m_pShaderManager = nullptr;
    ShapeMeshes* m_basicMeshes = nullptr;

    int m_loadedTextures = 0;
    TEXTURE_INFO m_textureIDs[16]{};

    std::vector<OBJECT_MATERIAL> m_objectMaterials;

    bool FindMaterial(const std::string& tag, OBJECT_MATERIAL& material);
    bool FindTexture(const std::string& tag, uint32_t& textureID);

    bool LoadTexture2D(const std::string& tag, const std::vector<std::string>& candidatePaths);
    void DeleteTextures();

    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);

    void SetShaderColor(
        float redColorValue,
        float greenColorValue,
        float blueColorValue,
        float alphaValue);

    void SetShaderMaterial(const std::string& materialTag);
    void SetShaderTexture(const std::string& textureTag);
    void DisableShaderTexture();

public:
    void PrepareScene();
    void RenderScene();

    void SetupSceneLights();
    void DefineObjectMaterials();
};
