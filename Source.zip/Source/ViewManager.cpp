///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// CS-330 Final Project
//
// Handles camera navigation, mouse orientation, scroll-speed control,
// and perspective/orthographic projection switching.
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

#include <GL/glew.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>

#include <algorithm>
#include <iostream>

namespace
{
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;

    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    Camera* g_pCamera = nullptr;

    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // Movement speed is changed with the mouse wheel.
    float gMovementSpeed = 3.5f;

    // false = perspective, true = orthographic.
    bool gOrthographicProjection = false;

    // Prevents repeated projection toggles while the key is held.
    bool gProjectionKeyWasDown = false;
}

// ---------------------------------------------------------------------------
// Constructor / destructor
// ---------------------------------------------------------------------------
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = nullptr;

    g_pCamera = new Camera();

    // Initial camera is placed far enough away to see the whole office.
    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
    g_pCamera->Front = glm::vec3(0.0f, -0.8f, -1.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 55.0f;
}

ViewManager::~ViewManager()
{
    m_pShaderManager = nullptr;
    m_pWindow = nullptr;

    if (g_pCamera != nullptr)
    {
        delete g_pCamera;
        g_pCamera = nullptr;
    }
}

// ---------------------------------------------------------------------------
// Create GLFW display window and register callbacks.
// ---------------------------------------------------------------------------
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        windowTitle,
        nullptr,
        nullptr);

    if (window == nullptr)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return nullptr;
    }

    glfwMakeContextCurrent(window);

    glfwSetCursorPosCallback(
        window,
        &ViewManager::Mouse_Position_Callback);

    glfwSetScrollCallback(
        window,
        &ViewManager::Mouse_Scroll_Callback);

    // Capture the mouse for continuous camera orientation.
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;

    return window;
}

// ---------------------------------------------------------------------------
// Mouse orientation: yaw and pitch.
// ---------------------------------------------------------------------------
void ViewManager::Mouse_Position_Callback(
    GLFWwindow* window,
    double xMousePos,
    double yMousePos)
{
    (void)window;

    if (g_pCamera == nullptr)
        return;

    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xOffset = static_cast<float>(xMousePos) - gLastX;
    float yOffset = gLastY - static_cast<float>(yMousePos);

    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

// ---------------------------------------------------------------------------
// Mouse wheel changes movement speed.
// This satisfies the final-project requirement that scroll controls
// how quickly the camera travels around the scene.
// ---------------------------------------------------------------------------
void ViewManager::Mouse_Scroll_Callback(
    GLFWwindow* window,
    double xOffset,
    double yOffset)
{
    (void)window;
    (void)xOffset;

    gMovementSpeed += static_cast<float>(yOffset) * 0.50f;

    // Keep the speed usable and prevent extreme values.
    if (gMovementSpeed < 0.5f)
    {
        gMovementSpeed = 0.5f;
    }
    else if (gMovementSpeed > 15.0f)
    {
        gMovementSpeed = 15.0f;
    }

    std::cout << "Camera speed: " << gMovementSpeed << std::endl;
}

// ---------------------------------------------------------------------------
// Keyboard navigation.
// WASD = horizontal/depth movement.
// Q/E = vertical movement.
// P = perspective.
// O = orthographic.
// ESC = exit.
// ---------------------------------------------------------------------------
void ViewManager::ProcessKeyboardEvents()
{
    if (m_pWindow == nullptr || g_pCamera == nullptr)
        return;

    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(m_pWindow, true);
    }

    // Standard camera movement uses the camera's current Front/Right vectors.
    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
    {
        g_pCamera->Position += g_pCamera->Front * gMovementSpeed * gDeltaTime;
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
    {
        g_pCamera->Position -= g_pCamera->Front * gMovementSpeed * gDeltaTime;
    }

    glm::vec3 right =
        glm::normalize(glm::cross(g_pCamera->Front, g_pCamera->Up));

    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
    {
        g_pCamera->Position -= right * gMovementSpeed * gDeltaTime;
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
    {
        g_pCamera->Position += right * gMovementSpeed * gDeltaTime;
    }

    // Q/E provide vertical camera movement.
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
    {
        g_pCamera->Position.y += gMovementSpeed * gDeltaTime;
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
    {
        g_pCamera->Position.y -= gMovementSpeed * gDeltaTime;
    }

    // P switches to perspective.
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
    {
        gOrthographicProjection = false;
    }

    // O switches to orthographic.
    if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
    {
        gOrthographicProjection = true;
    }
}

// ---------------------------------------------------------------------------
// Prepare view and projection matrices each frame.
// ---------------------------------------------------------------------------
void ViewManager::PrepareSceneView()
{
    if (g_pCamera == nullptr)
        return;

    glm::mat4 view;
    glm::mat4 projection;

    float currentFrame = static_cast<float>(glfwGetTime());
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    // Protect against a large time step after a pause/debug break.
    gDeltaTime = std::min(gDeltaTime, 0.05f);

    ProcessKeyboardEvents();

    view = g_pCamera->GetViewMatrix();

    float aspectRatio =
        static_cast<float>(WINDOW_WIDTH) /
        static_cast<float>(WINDOW_HEIGHT);

    if (gOrthographicProjection)
    {
        // Same camera orientation, different projection.
        float orthoSize = 12.0f;

        projection = glm::ortho(
            -orthoSize * aspectRatio,
             orthoSize * aspectRatio,
            -orthoSize,
             orthoSize,
             0.1f,
             100.0f);
    }
    else
    {
        projection = glm::perspective(
            glm::radians(g_pCamera->Zoom),
            aspectRatio,
            0.1f,
            100.0f);
    }

    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value(
            "viewPosition",
            g_pCamera->Position);
    }
}
