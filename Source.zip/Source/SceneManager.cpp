///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// CS-330 Final Project
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#include <GL/glew.h>
#include <glm/gtx/transform.hpp>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>


#include "stb_image.h"


namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

// ---------------------------------------------------------------------------
// Constructor / destructor
// ---------------------------------------------------------------------------
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
    DeleteTextures();

    m_pShaderManager = nullptr;

    if (m_basicMeshes != nullptr)
    {
        delete m_basicMeshes;
        m_basicMeshes = nullptr;
    }

    m_objectMaterials.clear();
}

// ---------------------------------------------------------------------------
// Material lookup
// ---------------------------------------------------------------------------
bool SceneManager::FindMaterial(const std::string& tag, OBJECT_MATERIAL& material)
{
    for (const OBJECT_MATERIAL& storedMaterial : m_objectMaterials)
    {
        if (storedMaterial.tag == tag)
        {
            material = storedMaterial;
            return true;
        }
    }

    return false;
}

// ---------------------------------------------------------------------------
// Texture lookup
// ---------------------------------------------------------------------------
bool SceneManager::FindTexture(const std::string& tag, uint32_t& textureID)
{
    for (int index = 0; index < m_loadedTextures; ++index)
    {
        if (m_textureIDs[index].tag == tag)
        {
            textureID = m_textureIDs[index].ID;
            return true;
        }
    }

    return false;
}

// ---------------------------------------------------------------------------
// Load one image texture. Several relative paths are tried so the
// project can be run from Visual Studio or from its Debug/Release folder.
// ---------------------------------------------------------------------------
bool SceneManager::LoadTexture2D(
    const std::string& tag,
    const std::vector<std::string>& candidatePaths)
{
    if (m_loadedTextures >= 16)
    {
        std::cerr << "Texture limit reached. Could not load: " << tag << std::endl;
        return false;
    }

    for (const std::string& path : candidatePaths)
    {
        std::ifstream file(path, std::ios::binary);
        if (!file.good())
        {
            continue;
        }
        file.close();

        int width = 0;
        int height = 0;
        int channels = 0;

        stbi_set_flip_vertically_on_load(true);

        unsigned char* imageData =
            stbi_load(path.c_str(), &width, &height, &channels, 0);

        if (imageData == nullptr)
        {
            continue;
        }

        GLenum imageFormat = GL_RGB;
        if (channels == 1)
            imageFormat = GL_RED;
        else if (channels == 4)
            imageFormat = GL_RGBA;

        GLuint textureID = 0;
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            imageFormat,
            width,
            height,
            0,
            imageFormat,
            GL_UNSIGNED_BYTE,
            imageData);

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(imageData);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].tag = tag;
        m_textureIDs[m_loadedTextures].ID = textureID;
        ++m_loadedTextures;

        std::cout << "Loaded texture: " << tag
            << " (" << width << "x" << height << ") from "
            << path << std::endl;

        return true;
    }

    std::cerr << "Could not load texture '" << tag
        << "'. Add a royalty-free 1024x1024-or-larger image "
        << "to the Textures folder." << std::endl;

    return false;
}

void SceneManager::DeleteTextures()
{
    for (int index = 0; index < m_loadedTextures; ++index)
    {
        if (m_textureIDs[index].ID != 0)
        {
            GLuint id = m_textureIDs[index].ID;
            glDeleteTextures(1, &id);
        }
        m_textureIDs[index].ID = 0;
        m_textureIDs[index].tag.clear();
    }

    m_loadedTextures = 0;
}

// ---------------------------------------------------------------------------
// Transformation helper
// ---------------------------------------------------------------------------
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 modelView;
    glm::mat4 scale;
    glm::mat4 rotationX;
    glm::mat4 rotationY;
    glm::mat4 rotationZ;
    glm::mat4 translation;

    // Required order: scale first, then rotate, then translate.
    scale = glm::scale(scaleXYZ);

    rotationX = glm::rotate(
        glm::radians(XrotationDegrees),
        glm::vec3(1.0f, 0.0f, 0.0f));

    rotationY = glm::rotate(
        glm::radians(YrotationDegrees),
        glm::vec3(0.0f, 1.0f, 0.0f));

    rotationZ = glm::rotate(
        glm::radians(ZrotationDegrees),
        glm::vec3(0.0f, 0.0f, 1.0f));

    translation = glm::translate(positionXYZ);

    modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

// ---------------------------------------------------------------------------
// Shader color/material/texture helpers
// ---------------------------------------------------------------------------
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(
        redColorValue,
        greenColorValue,
        blueColorValue,
        alphaValue);

    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

void SceneManager::SetShaderMaterial(const std::string& materialTag)
{
    OBJECT_MATERIAL material;

    if (m_pShaderManager != nullptr &&
        FindMaterial(materialTag, material))
    {
        m_pShaderManager->setVec3Value(
            "material.ambientColor", material.ambientColor);

        m_pShaderManager->setFloatValue(
            "material.ambientStrength", material.ambientStrength);

        m_pShaderManager->setVec3Value(
            "material.diffuseColor", material.diffuseColor);

        m_pShaderManager->setVec3Value(
            "material.specularColor", material.specularColor);

        m_pShaderManager->setFloatValue(
            "material.shininess", material.shininess);
    }
}

void SceneManager::SetShaderTexture(const std::string& textureTag)
{
    uint32_t textureID = 0;

    if (m_pShaderManager == nullptr)
        return;

    if (FindTexture(textureTag, textureID) && textureID != 0)
    {
        m_pShaderManager->setBoolValue(g_UseTextureName, true);
        m_pShaderManager->setIntValue(g_TextureValueName, 0);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, textureID);
    }
    else
    {
        DisableShaderTexture();
    }
}

void SceneManager::DisableShaderTexture()
{
    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setBoolValue(g_UseTextureName, false);
    }

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, 0);
}

// ---------------------------------------------------------------------------
// Materials
// ---------------------------------------------------------------------------
void SceneManager::DefineObjectMaterials()
{
    m_objectMaterials.clear();

    OBJECT_MATERIAL material;

    // Wood/desk material.
    material.ambientColor = glm::vec3(0.34f, 0.22f, 0.12f);
    material.ambientStrength = 0.80f;
    material.diffuseColor = glm::vec3(0.62f, 0.38f, 0.18f);
    material.specularColor = glm::vec3(0.25f, 0.16f, 0.08f);
    material.shininess = 28.0f;
    material.tag = "woodMaterial";
    m_objectMaterials.push_back(material);

    // Dark laptop/chair material.
    material.ambientColor = glm::vec3(0.25f, 0.27f, 0.30f);
    material.ambientStrength = 0.85f;
    material.diffuseColor = glm::vec3(0.34f, 0.36f, 0.40f);
    material.specularColor = glm::vec3(0.42f, 0.44f, 0.48f);
    material.shininess = 48.0f;
    material.tag = "darkMaterial";
    m_objectMaterials.push_back(material);

    // Light-colored notebook/cup material.
    material.ambientColor = glm::vec3(0.42f, 0.40f, 0.36f);
    material.ambientStrength = 0.82f;
    material.diffuseColor = glm::vec3(0.78f, 0.74f, 0.64f);
    material.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
    material.shininess = 40.0f;
    material.tag = "lightMaterial";
    m_objectMaterials.push_back(material);

    // Green plant material.
    material.ambientColor = glm::vec3(0.08f, 0.20f, 0.08f);
    material.ambientStrength = 0.78f;
    material.diffuseColor = glm::vec3(0.10f, 0.58f, 0.12f);
    material.specularColor = glm::vec3(0.16f, 0.25f, 0.16f);
    material.shininess = 24.0f;
    material.tag = "plantMaterial";
    m_objectMaterials.push_back(material);

    // Metal material for lamp.
    material.ambientColor = glm::vec3(0.28f, 0.29f, 0.32f);
    material.ambientStrength = 0.82f;
    material.diffuseColor = glm::vec3(0.46f, 0.48f, 0.52f);
    material.specularColor = glm::vec3(0.70f, 0.72f, 0.76f);
    material.shininess = 72.0f;
    material.tag = "metalMaterial";
    m_objectMaterials.push_back(material);
}

// ---------------------------------------------------------------------------
// Lighting
// ---------------------------------------------------------------------------
void SceneManager::SetupSceneLights()
{
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // Light 0: strong white point light.
    // This is the required point light and provides the main illumination.
    m_pShaderManager->setVec3Value(
        "lightSources[0].position",
        0.0f, 10.0f, 5.0f);

    m_pShaderManager->setVec3Value(
        "lightSources[0].ambientColor",
        0.42f, 0.42f, 0.42f);

    m_pShaderManager->setVec3Value(
        "lightSources[0].diffuseColor",
        0.88f, 0.88f, 0.88f);

    m_pShaderManager->setVec3Value(
        "lightSources[0].specularColor",
        1.0f, 1.0f, 1.0f);

    m_pShaderManager->setFloatValue(
        "lightSources[0].focalStrength",
        32.0f);

    m_pShaderManager->setFloatValue(
        "lightSources[0].specularIntensity",
        0.72f);

    // Light 1: colored pink/red fill light.
    // This satisfies the requirement for a colored light source.
    m_pShaderManager->setVec3Value(
        "lightSources[1].position",
        -4.0f, 7.0f, 3.0f);

    m_pShaderManager->setVec3Value(
        "lightSources[1].ambientColor",
        0.10f, 0.035f, 0.055f);

    m_pShaderManager->setVec3Value(
        "lightSources[1].diffuseColor",
        0.65f, 0.10f, 0.18f);

    m_pShaderManager->setVec3Value(
        "lightSources[1].specularColor",
        0.75f, 0.20f, 0.28f);

    m_pShaderManager->setFloatValue(
        "lightSources[1].focalStrength",
        32.0f);

    m_pShaderManager->setFloatValue(
        "lightSources[1].specularIntensity",
        0.25f);
}

// ---------------------------------------------------------------------------
// Scene preparation
// ---------------------------------------------------------------------------
void SceneManager::PrepareScene()
{
    DefineObjectMaterials();
    SetupSceneLights();

    // Load the basic meshes available
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadSphereMesh();

 
    LoadTexture2D(
        "wood",
        {
            "Textures/wood.jpg",
            "Textures/wood.png",
            "../Textures/wood.jpg",
            "../Textures/wood.png",
            "../../Textures/wood.jpg",
            "../../Textures/wood.png",
            "../../../Textures/wood.jpg",
            "../../../Textures/wood.png"
        });

    LoadTexture2D(
        "notebook",
        {
            "Textures/notebook.jpg",
            "Textures/notebook.png",
            "../Textures/notebook.jpg",
            "../Textures/notebook.png",
            "../../Textures/notebook.jpg",
            "../../Textures/notebook.png",
            "../../../Textures/notebook.jpg",
            "../../../Textures/notebook.png"
        });

    // Ensure no texture state leaks into the next frame/object.
    DisableShaderTexture();
}

// ---------------------------------------------------------------------------
// Final office scene
// ---------------------------------------------------------------------------
void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    glm::vec3 positionXYZ;
    float xRot = 0.0f;
    float yRot = 0.0f;
    float zRot = 0.0f;

    // =======================================================================
    // FLOOR - Plane primitive
    // =======================================================================
    scaleXYZ = glm::vec3(12.0f, 1.0f, 9.0f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.14f, 0.09f, 0.05f, 1.0f);
    SetShaderMaterial("woodMaterial");
    DisableShaderTexture();
    m_basicMeshes->DrawPlaneMesh();

    // =======================================================================
    // DESK TOP - Box primitive
    // =======================================================================
    scaleXYZ = glm::vec3(5.5f, 0.30f, 2.5f);
    positionXYZ = glm::vec3(0.0f, 4.0f, 0.0f);

    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    SetShaderMaterial("woodMaterial");
    SetShaderTexture("wood");
    m_basicMeshes->DrawBoxMesh();

    // =======================================================================
    // DESK LEGS - Cylinder primitives
    // =======================================================================
    SetShaderMaterial("metalMaterial");
    DisableShaderTexture();

    scaleXYZ = glm::vec3(0.45f, 4.0f, 0.45f);
    positionXYZ = glm::vec3(-4.5f, 2.0f, -1.7f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.25f, 0.27f, 0.30f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    positionXYZ = glm::vec3(4.5f, 2.0f, -1.7f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawCylinderMesh();

    positionXYZ = glm::vec3(-4.5f, 2.0f, 1.7f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawCylinderMesh();

    positionXYZ = glm::vec3(4.5f, 2.0f, 1.7f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawCylinderMesh();

    // =======================================================================
    // LAPTOP BASE - part 1 of a multi-primitive object
    // =======================================================================
    SetShaderMaterial("darkMaterial");

    scaleXYZ = glm::vec3(2.3f, 0.22f, 1.55f);
    positionXYZ = glm::vec3(0.5f, 4.55f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.16f, 0.18f, 0.21f, 1.0f);
    DisableShaderTexture();
    m_basicMeshes->DrawBoxMesh();

    // Laptop screen - part 2 of the multi-primitive object.
    scaleXYZ = glm::vec3(2.25f, 1.45f, 0.18f);
    positionXYZ = glm::vec3(0.5f, 5.95f, -1.25f);
    SetTransformations(scaleXYZ, -8.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.18f, 0.20f, 0.24f, 1.0f);
    m_basicMeshes->DrawBoxMesh();

    // Laptop screen display.
    scaleXYZ = glm::vec3(1.85f, 1.08f, 0.08f);
    positionXYZ = glm::vec3(0.5f, 5.95f, -1.43f);
    SetTransformations(scaleXYZ, -8.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.12f, 0.38f, 0.55f, 1.0f);
    m_basicMeshes->DrawBoxMesh();

    // Laptop hinge cylinder.
    scaleXYZ = glm::vec3(0.18f, 2.0f, 0.18f);
    positionXYZ = glm::vec3(0.5f, 4.75f, -1.22f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 90.0f, positionXYZ);
    SetShaderColor(0.30f, 0.32f, 0.35f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // =======================================================================
    // NOTEBOOK - Box primitive with second texture
    // =======================================================================
    SetShaderMaterial("lightMaterial");

    scaleXYZ = glm::vec3(1.4f, 0.08f, 1.0f);
    positionXYZ = glm::vec3(-2.7f, 4.45f, 0.35f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, -8.0f, positionXYZ);
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    SetShaderTexture("notebook");
    m_basicMeshes->DrawBoxMesh();

    // =======================================================================
    // CUP 1 - Cylinder + sphere accent
    // =======================================================================
    SetShaderMaterial("lightMaterial");
    DisableShaderTexture();

    scaleXYZ = glm::vec3(0.55f, 0.75f, 0.55f);
    positionXYZ = glm::vec3(2.6f, 4.95f, 0.45f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.88f, 0.82f, 0.70f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Cup 1 handle represented with a sphere scaled thin.
    scaleXYZ = glm::vec3(0.20f, 0.35f, 0.45f);
    positionXYZ = glm::vec3(3.15f, 4.95f, 0.45f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.88f, 0.82f, 0.70f, 1.0f);
    m_basicMeshes->DrawSphereMesh();

    // =======================================================================
    // CUP 2
    // =======================================================================
    scaleXYZ = glm::vec3(0.45f, 0.65f, 0.45f);
    positionXYZ = glm::vec3(3.8f, 4.85f, 0.90f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.70f, 0.75f, 0.82f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // =======================================================================
    // PLANT POT - Box/cylinder combination
    // =======================================================================
    scaleXYZ = glm::vec3(0.95f, 0.75f, 0.95f);
    positionXYZ = glm::vec3(-4.0f, 4.95f, 0.55f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.55f, 0.25f, 0.10f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Plant stem.
    SetShaderMaterial("plantMaterial");
    scaleXYZ = glm::vec3(0.14f, 1.3f, 0.14f);
    positionXYZ = glm::vec3(-4.0f, 6.45f, 0.55f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.10f, 0.45f, 0.10f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Plant leaves.
    scaleXYZ = glm::vec3(0.45f, 0.75f, 0.20f);
    positionXYZ = glm::vec3(-4.65f, 6.85f, 0.55f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, -30.0f, positionXYZ);
    SetShaderColor(0.08f, 0.65f, 0.12f, 1.0f);
    m_basicMeshes->DrawSphereMesh();

    positionXYZ = glm::vec3(-3.40f, 6.90f, 0.55f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 30.0f, positionXYZ);
    m_basicMeshes->DrawSphereMesh();

    scaleXYZ = glm::vec3(0.35f, 0.65f, 0.18f);
    positionXYZ = glm::vec3(-4.0f, 7.15f, 0.55f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawSphereMesh();

    // =======================================================================
    // LAMP - multiple primitive parts
    // =======================================================================
    SetShaderMaterial("metalMaterial");

    // Lamp base.
    scaleXYZ = glm::vec3(0.75f, 0.18f, 0.75f);
    positionXYZ = glm::vec3(4.2f, 4.55f, -1.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.35f, 0.36f, 0.38f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Lamp vertical support.
    scaleXYZ = glm::vec3(0.16f, 2.2f, 0.16f);
    positionXYZ = glm::vec3(4.2f, 6.65f, -1.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawCylinderMesh();

    // Lamp arm.
    scaleXYZ = glm::vec3(0.14f, 2.0f, 0.14f);
    positionXYZ = glm::vec3(3.65f, 8.0f, -1.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, -55.0f, positionXYZ);
    m_basicMeshes->DrawCylinderMesh();

    // Lamp shade using a cone primitive.
    SetShaderMaterial("lightMaterial");
    scaleXYZ = glm::vec3(0.85f, 0.95f, 0.90f);
    positionXYZ = glm::vec3(2.85f, 8.75f, -1.0f);
    SetTransformations(scaleXYZ, 180.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.72f, 0.68f, 0.55f, 1.0f);
    m_basicMeshes->DrawConeMesh();

    // =======================================================================
    // CHAIR - two boxes and cylinders, matching the Module 2 plan
    // =======================================================================
    SetShaderMaterial("darkMaterial");

    // Seat.
    scaleXYZ = glm::vec3(2.0f, 0.30f, 1.9f);
    positionXYZ = glm::vec3(-5.8f, 2.25f, 0.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.28f, 0.30f, 0.34f, 1.0f);
    m_basicMeshes->DrawBoxMesh();

    // Chair back.
    scaleXYZ = glm::vec3(2.0f, 2.4f, 0.30f);
    positionXYZ = glm::vec3(-5.8f, 4.25f, 1.65f);
    SetTransformations(scaleXYZ, -5.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawBoxMesh();

    // Four chair legs.
    scaleXYZ = glm::vec3(0.28f, 2.0f, 0.28f);

    positionXYZ = glm::vec3(-7.15f, 1.0f, -1.25f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawCylinderMesh();

    positionXYZ = glm::vec3(-4.45f, 1.0f, -1.25f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawCylinderMesh();

    positionXYZ = glm::vec3(-7.15f, 1.0f, 1.25f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawCylinderMesh();

    positionXYZ = glm::vec3(-4.45f, 1.0f, 1.25f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    m_basicMeshes->DrawCylinderMesh();

    DisableShaderTexture();
}

