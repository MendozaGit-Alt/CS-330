///////////////////////////////////////////////////////////////////////////////
// MainCode.cpp
// CS-330 Final Project
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include <GL/glew.h>
#include "GLFW/glfw3.h"

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

namespace
{
    const char* const WINDOW_TITLE = "CS330 Final Project";

    GLFWwindow* g_Window = nullptr;
    SceneManager* g_SceneManager = nullptr;
    ShaderManager* g_ShaderManager = nullptr;
    ViewManager* g_ViewManager = nullptr;
}

bool InitializeGLFW();
bool InitializeGLEW();

int main(int argc, char* argv[])
{
    (void)argc;
    (void)argv;

    if (!InitializeGLFW())
    {
        return EXIT_FAILURE;
    }

    g_ShaderManager = new ShaderManager();

    g_ViewManager = new ViewManager(g_ShaderManager);

    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);

    if (g_Window == nullptr)
    {
        delete g_ViewManager;
        delete g_ShaderManager;
        return EXIT_FAILURE;
    }

    if (!InitializeGLEW())
    {
        glfwTerminate();
        delete g_ViewManager;
        delete g_ShaderManager;
        return EXIT_FAILURE;
    }

  
    g_ShaderManager->LoadShaders(
        "../../Utilities/shaders/vertexShader.glsl",
        "../../Utilities/shaders/fragmentShader.glsl");

    g_ShaderManager->use();

    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();

    while (!glfwWindowShouldClose(g_Window))
    {
        glEnable(GL_DEPTH_TEST);

        // A dark neutral background keeps the illuminated office readable.
        glClearColor(0.035f, 0.045f, 0.055f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        g_ViewManager->PrepareSceneView();
        g_SceneManager->RenderScene();

        glfwSwapBuffers(g_Window);
        glfwPollEvents();
    }

    delete g_SceneManager;
    g_SceneManager = nullptr;

    delete g_ViewManager;
    g_ViewManager = nullptr;

    delete g_ShaderManager;
    g_ShaderManager = nullptr;

    glfwTerminate();

    return EXIT_SUCCESS;
}

bool InitializeGLFW()
{
    if (!glfwInit())
    {
        std::cerr << "ERROR: GLFW failed to initialize." << std::endl;
        return false;
    }

#ifdef __APPLE__
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif

    return true;
}

bool InitializeGLEW()
{
    GLenum result = glewInit();

    if (GLEW_OK != result)
    {
        std::cerr << "GLEW initialization failed: "
                  << glewGetErrorString(result) << std::endl;
        return false;
    }

    std::cout << "INFO: OpenGL Successfully Initialized" << std::endl;
    std::cout << "INFO: OpenGL Version: "
              << glGetString(GL_VERSION) << std::endl;

    return true;
}
